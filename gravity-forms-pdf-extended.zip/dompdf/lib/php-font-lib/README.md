# PHP-font-lib

To use DOMPDF you must copy PHP-font-lib to this directory.

PHP-font-lib is available here: https://github.com/PhenX/php-font-lib

If you installed DOMPDF using composer, PHP-font-lib will already be
installed as a dependency, and you can leave this directory empty.

For more details on composer, please visit http://getcomposer.org/
