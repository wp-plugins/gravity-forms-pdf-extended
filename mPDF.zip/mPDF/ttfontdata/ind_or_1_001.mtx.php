<?php
$name='ind_or_1_001';
$type='TTF';
$desc=array (
  'Ascent' => 1000,
  'Descent' => -660,
  'CapHeight' => 1000,
  'Flags' => 4,
  'FontBBox' => '[-867 -690 1467 1016]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-371;
$ut=47;
$ttffile='G:/Blue Liquid Designs/4) BLUE LIQUID DESIGNS/12) FTP/2.2.0/mPDF/ttfonts/ind_or_1_001.ttf';
$TTCfontID='0';
$originalsize=162552;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ind_or_1_001';
$panose=' 0 0 2 b 6 6 3 8 4 2 2 4';
$kerninfo=array (
);
$haskerninfo=true;
$unAGlyphs=false;
?>